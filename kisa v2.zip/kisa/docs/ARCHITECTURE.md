# KISA — Architecture

A fork-first architecture that leverages [Natively](https://github.com/evinjohnn/natively-cluely-ai-assistant) (AGPL-3.0) as the foundation and adds a thin franchise-sales-specific layer on top.

For component-by-component justification with alternatives compared, see [STACK.md](./STACK.md). For the visual design system, see [UI_SYSTEM.md](./UI_SYSTEM.md).

---

## 1. Product in one sentence

A transparent always-on-top overlay that listens to your live Zoom call, understands what the prospective franchisee just said, and streams Claude-grounded, three-card responses onto your screen within ~1 second.

---

## 2. The Latency Budget

End-to-end target: **< 1,200 ms** from prospect's last word → first token on your screen.

| Stage | Budget | Verified Source |
|---|---|---|
| Audio capture → Deepgram first partial | 250 ms | Deepgram Nova-3 p95 |
| End-of-utterance detection | 400 ms | Deepgram `endpointing=400` |
| Retrieval (sqlite-vec, k=4) | 40 ms | Measured in Natively prod |
| Claude Haiku TTFT (KB prompt-cached) | 350 ms | Anthropic SLA p50 |
| SSE → React render | 20 ms | Standard browser |
| **Total to first token** | **~1.06 s** | ✅ Under budget |

Prompt caching cuts ~70% of input cost & latency on every turn because Termsheet + GC + FAQs are identical every call.

---

## 3. End-to-End Flow

```
┌─────────────────────────────────────────────────────────────────────┐
│  Zoom Call (Mac/Win desktop)                                        │
│   ├─ Mic (You / BDM)                                                │
│   └─ System Audio (Prospect)  ── via BlackHole / VB-Cable           │
└──────────────────────────┬──────────────────────────────────────────┘
                           │  16-bit PCM, 16kHz, dual-channel
                           ▼
┌─────────────────────────────────────────────────────────────────────┐
│  KISA Desktop (forked from Natively)                                │
│                                                                     │
│  ┌──────────────────┐   ┌──────────────────┐   ┌────────────────┐   │
│  │ Rust Audio Capture│──▶│ Deepgram Nova-3  │──▶│ Turn Manager  │   │
│  │ (zero-copy NAPI) │   │   OR  Whisper-v3 │   │ (filter:      │   │
│  │  ★ from Natively  │   │   ★ from Natively│   │  prospect    │   │
│  └──────────────────┘   └──────────────────┘   │  only)        │   │
│                                                 └───────┬───────┘   │
│                                                         ▼           │
│                                              ┌──────────────────┐   │
│                                              │ KISA Backend(SSE)│   │
│                                              └──────────────────┘   │
│                                                                     │
│  ┌───────────────────────────────────────────────────────────────┐  │
│  │ OVERLAY (Glassmorphism 2.0) — see UI_SYSTEM.md               │  │
│  │ ① SAY THIS   ② KEY FACT   ③ IF THEY PUSH BACK   ← KISA DELTA │  │
│  └───────────────────────────────────────────────────────────────┘  │
└──────────────────────────┬──────────────────────────────────────────┘
                           │  WebSocket (transcript chunks)
                           ▼
┌─────────────────────────────────────────────────────────────────────┐
│  Backend (Node + Fastify, Fly.io Mumbai region)                     │
│                                                                     │
│  ┌──────────────┐   ┌─────────────────────┐   ┌──────────────────┐  │
│  │ Conversation │──▶│ Retriever            │──▶│ Claude Haiku 4.5 │  │
│  │ State (Redis)│   │ sqlite-vec (local)   │   │ streaming +      │  │
│  │              │   │  OR  pgvector (cloud)│   │ KB prompt-cached │  │
│  └──────────────┘   └─────────────────────┘   └────────┬─────────┘  │
│                                                        │ SSE        │
└────────────────────────────────────────────────────────┼────────────┘
                                                        ▼
                                              back to Overlay UI

  ★ = inherited from Natively unchanged
```

---

## 4. What we inherit vs. what we build

See [STACK.md § The Single Decision That Saves 4 Weeks](./STACK.md) for the full table. Short version:

**Inherited from Natively (no work):**
Audio capture · Whisper local + Deepgram cloud STT · sqlite-vec RAG · PDF/DOCX ingest · stealth overlay window · BYOK keys · cross-window state sync · Claude SDK integration.

**KISA delta (~5 days):**
Franchise sales system prompt · three-card structured UI · brand multi-tenancy · doc-type metadata filter · Glassmorphism 2.0 redesign · Indian context (INR, Tier-2 cities) · session review with citations.

---

## 5. The Knowledge Pack (per franchise brand)

Uploaded once by admin, versioned, indexed by Natively's RAG pipeline:

```
/brand/{brand_id}/
  ├── termsheet.pdf          → chunks tagged doc_type="commercials"
  ├── general_conditions.pdf → tagged "legal"
  ├── faqs.md                → tagged "objection"
  ├── unit_economics.xlsx    → tagged "roi"
  ├── pitch_deck.pdf         → tagged "story"
  └── brand_voice.md         → injected as system prompt (tone)
```

Each chunk carries `{brand_id, doc_type, page, section}` metadata. The retriever filters by intent — e.g., investor asks about money → only `commercials + roi`. This is the **KISA delta** on top of Natively's generic RAG.

---

## 6. The Reasoning Loop

On every prospect-turn-end (detected via Natively's existing turn manager, filtered to prospect channel only):

```python
turn = transcript.last_prospect_utterance()
intent = classify(turn)   # cheap Haiku one-liner → commercials|legal|objection|roi|story|general
chunks = sqlite_vec.search(
    query=turn,
    filter={"brand_id": session.brand, "doc_type": intent.docs},
    k=4
)

claude.messages.stream(
    model="claude-haiku-4-5-20251001",
    system=[
        {"type": "text", "text": SALES_COACH_PROMPT,
         "cache_control": {"type": "ephemeral"}},
        {"type": "text", "text": KNOWLEDGE_PACK_FOR_BRAND,
         "cache_control": {"type": "ephemeral"}},
    ],
    messages=[
        {"role": "user", "content": f"""
        ROLLING TRANSCRIPT (last 60s):
        {transcript.window(60)}

        PROSPECT JUST SAID: "{turn}"

        RELEVANT EXCERPTS:
        {format(chunks)}

        Respond in JSON: {{reply, key_fact, objection_handler}}
        Keep `reply` under 35 words, conversational, first-person, Indian English.
        """}
    ],
    max_tokens=300,
)
```

Three guarantees:
1. **Caches** the 20–40k token knowledge pack → ~10× cheaper & faster on every turn after the first.
2. **Constrains** output to 3 short cards → no walls of text.
3. **Grounds** on excerpts with page refs → every claim is auditable.

---

## 7. Cost (per 60-min call)

| Item | Cost |
|---|---|
| Deepgram Nova-3 STT (60 min) | ₹22 |
| Claude Haiku (cached KB, ~40 turns) | ₹18 |
| sqlite-vec queries | ~₹0 |
| Voyage embedding (amortized) | ~₹1 |
| Infra | ₹2 |
| **Per call** | **~₹43** |

At 500 calls/month/BDM → ~₹21.5k/mo gross cost. SaaS price ₹3–5k/BDM/mo → 7–9× gross margin.

---

## 8. What we deliberately leave out (v1)

- No fine-tuning — prompt caching + RAG covers it
- No Zoom SDK / Zoom App integration — virtual audio is Zoom-version-proof
- No on-device LLM in v1 — Haiku API is faster than any local 8B
- No agentic tool-use — one LLM call per turn, predictable latency
- No CRM write-back — add in v2 from session JSON

---

## 9. Risks & mitigations

| Risk | Mitigation |
|---|---|
| Deepgram misses strong Indian Tier-2 accents | Switch to Whisper-large-v3-turbo (already in Natively) per-user |
| LLM gives a wrong number (hallucination) | Hard rule: every fact card must cite a chunk source; if no chunk, card shows "—" |
| AGPL forces source disclosure on SaaS | Either open-source the KISA delta, or buy commercial Natively license before launch |
| Overlay visible in prospect's screen-share | Natively's stealth mode hides from screen capture; verified on Zoom/Meet/Teams |
| BDM reads stale reply (overlap with new utterance) | Cancel-in-flight SSE on every new prospect turn |

---

For implementation, see [BUILD_GUIDE.md](./BUILD_GUIDE.md).
