# KISA — UI System (Glassmorphism 2.0)

A premium, glanceable, Zoom-overlay-friendly UI built on the **shadcn + Aceternity + Magic UI** stack. Every element specified below is copy-pasteable from existing libraries — zero custom design system to maintain.

---

## Design philosophy

- **Glanceable, not interactive.** The BDM is speaking. They have 0.5s to read a card. No nested menus, no scrolling.
- **Glassmorphism 2.0.** Multi-layer backdrop filters, semi-opaque text films, relative color syntax. Premium without performance lag.
- **Readable over any Zoom background.** Dark glass + 30% film behind text + 95% white at 1.4 line-height.
- **Streamed.** Tokens arrive word-by-word so the BDM starts reading before generation completes.

---

## Component library stack

| Library | Role in KISA | Why |
|---|---|---|
| **shadcn/ui** | Base primitives (Card, Badge, Button, Tooltip) | Copy-paste, accessible, owns the code |
| **Aceternity UI** | "Glare Card", "Background Beams", "Text Generate Effect" for cards | Best-in-class motion-rich glass effects |
| **Magic UI** | "Animated Beam", "Neon Gradient Card", "Border Beam" for live indicator | Polished micro-interactions |
| **Cult UI** | AI chat patterns, streaming text patterns | Built specifically for AI app UX |
| **Framer Motion** | All animations | shadcn/Aceternity standard |
| **Tailwind CSS** | All styling | Standard |

Install order: `shadcn/ui init → tailwind plugin → framer-motion → copy components from each library as needed.`

---

## Design tokens

```css
:root {
  /* Surfaces — Glassmorphism 2.0 */
  --glass-bg:         rgba(15, 15, 20, 0.72);   /* card background */
  --glass-film:       rgba(15, 15, 20, 0.30);   /* text-film behind text per 2026 a11y rule */
  --glass-border:     rgba(255, 255, 255, 0.08);
  --glass-blur:       28px;
  --glass-saturation: 180%;

  /* Brand — sales-pitch warmth */
  --accent-primary:   #C7A871;  /* aged-gold, conveys legacy/trust */
  --accent-success:   #4ADE80;  /* live indicator */
  --accent-warn:      #F5B642;  /* paused state */

  /* Type — high readability over busy Zoom backgrounds */
  --text-primary:     #FAFAFB;
  --text-secondary:   #B8B8C2;
  --text-tertiary:    #717180;

  /* Motion */
  --ease-emphasized:  cubic-bezier(0.2, 0, 0, 1);
  --duration-fast:    180ms;
  --duration-base:    280ms;
}

.glass-card {
  background: var(--glass-bg);
  backdrop-filter: blur(var(--glass-blur)) saturate(var(--glass-saturation));
  -webkit-backdrop-filter: blur(var(--glass-blur)) saturate(var(--glass-saturation));
  border: 1px solid var(--glass-border);
  border-radius: 18px;
  box-shadow:
    0 1px 0 rgba(255,255,255,0.04) inset,    /* highlight */
    0 0 0 1px rgba(0,0,0,0.4),               /* edge */
    0 20px 40px -8px rgba(0,0,0,0.5);        /* lift */
}
```

---

## The overlay window

- Size: **380 × 540 px**
- Position: **top-right of primary display**, 24px gutters
- `transparent: true, frame: false, alwaysOnTop: true, hasShadow: false`
- Always-on-top level: `screen-saver`
- `setIgnoreMouseEvents(true, { forward: true })` — passes mouse through empty regions, captures clicks only on cards

```
┌─────────────────────────────────────────┐
│  ● Live  ·  Rajesh M. · Tier-2 Indore  │   ← LiveBadge component
├─────────────────────────────────────────┤
│                                         │
│  SAY THIS                               │   ← PrimaryCard (Aceternity GlareCard)
│  ┌───────────────────────────────────┐  │
│  │ "Our Tier-2 outlets break even in │  │
│  │  14 months on average — I can     │  │
│  │  show you the Indore P&L now."    │  │
│  └───────────────────────────────────┘  │
│                                         │
├─────────────────────────────────────────┤
│  KEY FACT                               │   ← FactCard (compact)
│  ┌───────────────────────────────────┐  │
│  │ Avg payback: 14 mo · ROI: 38% Y2  │  │
│  │ ↳ Termsheet §4.2                  │  │
│  └───────────────────────────────────┘  │
│                                         │
├─────────────────────────────────────────┤
│  IF THEY PUSH BACK                      │   ← ObjectionCard
│  ┌───────────────────────────────────┐  │
│  │ On royalty (8%): justify with     │  │
│  │ brand marketing spend ₹12 Cr/yr   │  │
│  │ ↳ FAQ #11                         │  │
│  └───────────────────────────────────┘  │
│                                         │
└─────────────────────────────────────────┘
  [⏸ Cmd+⇧+P]   [📌 Pin]   [📝 Note]
```

---

## Component recipes

### 1. `LiveBadge` — top status pill

- Base: shadcn `Badge`
- Effect: Magic UI **Border Beam** on the dot (animated glow when active)
- States: `live` (green pulse) · `paused` (amber) · `error` (red)
- Width: hugs content

```tsx
<div className="flex items-center gap-2 text-xs">
  <span className="relative flex h-2 w-2">
    <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75" />
    <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-500" />
  </span>
  <span className="text-white/90">Live</span>
  <span className="text-white/40">·</span>
  <span className="text-white/70">{prospectName}</span>
  <span className="text-white/40">·</span>
  <span className="text-white/50">{prospectContext}</span>
</div>
```

### 2. `PrimaryCard` — "SAY THIS"

The hero. Largest text, most prominent glow.

- Base: Aceternity **Glare Card** (subtle moving sheen on hover)
- Streaming text: Aceternity **Text Generate Effect** OR Cult UI streaming pattern → tokens fade-in word-by-word
- Typography: 17px / 1.5, white at 95% opacity, weight 500
- Padding: 18px
- Quote marks rendered in `--accent-primary` for visual rhythm
- Max 35 words (enforced by the LLM)

### 3. `FactCard` — "KEY FACT"

Compact, scannable, with source citation.

- Layout: two rows — fact line (15px, mono-tabular numbers), citation (12px, `--text-tertiary`)
- Numbers (`14 mo`, `38%`, `₹12 Cr`) get `--accent-primary` color
- Source line uses ↳ arrow + filename + section anchor

### 4. `ObjectionCard` — "IF THEY PUSH BACK"

A "second-best" reply for likely pushback.

- Same layout as FactCard
- Slightly desaturated background (`rgba(15,15,20,0.6)`) to visually de-prioritize vs PrimaryCard

### 5. Controls bar — bottom

- `pause` · `pin` · `note` keyboard hint chips
- Aceternity **Magnetic Button** on hover
- Pause toggles the LiveBadge to amber

---

## Streaming text behavior

The single most premium-feeling UX choice in KISA.

- Server SSE pushes `text_delta` events
- Each new word appears with:
  - `opacity: 0 → 1` over 120ms (Framer Motion `AnimatePresence`)
  - `y: 4px → 0` slight rise
  - `filter: blur(2px) → blur(0)` soft focus-in (Magic UI pattern)
- A subtle blinking cursor follows the latest token until stream completes
- On stream complete, cursor fades out over 400ms

Code stub:

```tsx
import { motion, AnimatePresence } from 'framer-motion';

function StreamingText({ tokens, isStreaming }) {
  return (
    <div className="text-[17px] leading-[1.5] text-white/95">
      <AnimatePresence>
        {tokens.map((tok, i) => (
          <motion.span
            key={i}
            initial={{ opacity: 0, y: 4, filter: 'blur(2px)' }}
            animate={{ opacity: 1, y: 0, filter: 'blur(0)' }}
            transition={{ duration: 0.12, ease: [0.2, 0, 0, 1] }}
          >
            {tok}{' '}
          </motion.span>
        ))}
      </AnimatePresence>
      {isStreaming && (
        <motion.span
          className="inline-block w-[2px] h-[1em] bg-amber-200/80 align-middle ml-[1px]"
          animate={{ opacity: [1, 0.2, 1] }}
          transition={{ duration: 0.9, repeat: Infinity }}
        />
      )}
    </div>
  );
}
```

---

## Backdrop & ambient effects

- Subtle **Background Beams** (Aceternity) at 6% opacity behind cards for depth, animated extremely slowly (one full sweep per 20s) so they don't distract
- **No** particles, **no** color flashes, **no** sound — this is a sales tool, not a game

---

## Accessibility (2026 rule, non-negotiable)

> Never place text directly on a 10% opacity background. Add a semi-opaque "film" (~30% opacity) behind the text itself.

Implemented via the `.glass-card` token above — the 72%-opacity background card sits on top of the 30%-opacity text film when the overlay is over busy Zoom backgrounds (shared slides, video feeds).

---

## Implementation order (matches BUILD_GUIDE Phase 4)

1. Install Tailwind + shadcn/ui base in the forked Natively renderer
2. Drop in the `.glass-card` token + dark theme
3. Replace Natively's chat panel with the three-card layout
4. Wire SSE → `StreamingText` component in PrimaryCard
5. Add LiveBadge with prospect name from session
6. Add Aceternity Glare effect, Magic UI Border Beam
7. Add control bar with keyboard chips
8. Test over a real Zoom call with screen sharing

Done correctly, this looks like a $50/mo Cluely-tier product on day one.
