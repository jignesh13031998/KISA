# KISA — Step-by-Step Build Guide

A fork-first, copy-paste-ready playbook for Claude Code. Each step is a self-contained prompt with an acceptance test. Run in order, verify each before moving on.

**Total time, single engineer: ~5 working days to shippable v1.**

---

## Phase 0 — Fork & rebrand (~half day)

### Step 0.1 — Fork Natively

**Prompt to terminal Claude:**
> Clone https://github.com/evinjohnn/natively-cluely-ai-assistant into a new folder `kisa-app`. Read the project's CONTRIBUTING.md, README, and the top-level folder structure. Report back: (a) the entry points for the Electron main process, renderer, native Rust audio module, RAG/sqlite-vec layer, LLM call layer; (b) where the Sales persona prompt lives if it already exists; (c) the build command sequence to run on macOS. Do NOT modify any files yet.

**Acceptance:** You receive a clear file-by-file map of what to touch. `npm install && npm run build:native && npm start` opens the Natively app on your machine.

---

### Step 0.2 — Rebrand to KISA

**Prompt:**
> In `kisa-app`, find every occurrence of "Natively" / "natively" / project name strings in `package.json`, `electron-builder.yml`, `src/`, app menu titles, About dialog, window titles, dock name, and rename them to "KISA". Replace the app icon at `build/icon.{png,icns,ico}` with a placeholder I'll provide later (use a 1024×1024 solid gold square `#C7A871` for now). Update `productName`, `appId` to `com.kisa.copilot`, and the bundle identifier. Do NOT touch attribution in NOTICES/LICENSE/AGPL files — those must remain.

**Acceptance:** App launches with "KISA" in the dock, title bar, and menu. AGPL LICENSE file untouched. `git diff` is clean and focused on branding only.

---

### Step 0.3 — Create the KISA repo on top of the fork

**Prompt:**
> Initialize a new git history in `kisa-app` keeping the AGPL license file. Set `origin` to `git@github.com:jignesh13031998/KISA.git`. Add an `UPSTREAM.md` at the root that documents: which Natively commit SHA we forked from, what files we expect to diverge from upstream, and the merge strategy for pulling in upstream security fixes (quarterly rebase against `upstream/main`).

**Acceptance:** Repo has clean single initial commit + AGPL preserved + UPSTREAM.md documents fork lineage.

---

## Phase 1 — Configure for franchise sales (~half day)

### Step 1.1 — Write the KISA sales-coach system prompt

**Prompt:**
> Locate Natively's persona / system-prompt file (likely under `src/main/prompts/` or `src/personas/`). Create a new persona `franchise-sales-bdm` with the following system prompt (paste verbatim):
>
> ```
> You are KISA, a real-time co-pilot for a Business Development Manager (BDM) pitching a franchise opportunity to a prospective investor in India. The BDM is on a live video call. You will receive (1) a rolling 60-second transcript, (2) the prospect's most recent utterance, (3) the most relevant excerpts from the franchise's Termsheet, General Conditions, FAQs, Unit Economics, Pitch Deck, and Brand Voice notes.
>
> Your job: produce a JSON object with three fields the BDM can read in under 2 seconds and speak as their own:
> {
>   "reply":              "≤35 words, first-person, conversational, Indian English. The BDM will say this verbatim.",
>   "key_fact":           "≤20 words. One concrete number or fact that backs the reply. Always include the source ref (e.g., 'Termsheet §4.2' or 'FAQ #11').",
>   "objection_handler":  "≤30 words. The most likely pushback to the reply + how to handle it. Include source ref."
> }
>
> Rules:
> - Never invent numbers. If no chunk supports a number, write "—" and ask a clarifying question instead.
> - Use Indian financial conventions: ₹, lakh, crore.
> - Match the brand_voice.md tone exactly.
> - Be specific to the prospect's city tier / industry context if mentioned.
> - Never apologize or use AI-tells like "great question". Speak like a confident senior BDM.
> ```
>
> Wire this as the default persona for KISA. Remove or hide the original Natively interview persona from the persona picker UI.

**Acceptance:** A test call with a sample transcript produces a JSON in the required schema with no hallucinated numbers.

---

### Step 1.2 — Add doc_type metadata to ingest

**Prompt:**
> Natively's "Reference Files" ingestion stores PDFs/DOCXs as generic chunks. Extend the ingest layer (likely `src/main/rag/ingest.ts`) so that when a user uploads a document, they also pick a `doc_type` from a dropdown: `termsheet | general_conditions | faq | unit_economics | pitch_deck | brand_voice`. Persist this on every chunk row in sqlite-vec. Update the retrieval call to accept an optional `doc_types: string[]` filter and apply it as a WHERE clause before vector search.

**Acceptance:** Upload a termsheet PDF tagged "termsheet" → all its chunks have `doc_type="termsheet"`. Retrieval with `doc_types=["termsheet"]` returns only termsheet chunks.

---

### Step 1.3 — Intent classifier → doc_type filter

**Prompt:**
> Add a pre-retrieval intent classifier. Before each turn, call Claude Haiku with a one-line system prompt that classifies the prospect's utterance into one of: `commercials | legal | objection | roi | story | general`. Map each intent to a set of `doc_types`:
> - commercials → [termsheet, faq]
> - legal → [general_conditions, termsheet]
> - objection → [faq, brand_voice]
> - roi → [unit_economics, pitch_deck]
> - story → [pitch_deck, brand_voice]
> - general → all
>
> Pass the filtered `doc_types` to the retriever. Log every classification + retrieved chunk IDs to console for tuning.

**Acceptance:** "What is the royalty fee?" classifies as `commercials` and retrieves only termsheet/FAQ chunks.

---

### Step 1.4 — Enable Claude Haiku 4.5 + prompt caching

**Prompt:**
> In the LLM call layer, switch the default model from whatever Natively ships with to `claude-haiku-4-5-20251001`. Restructure the call to use Anthropic's prompt caching: place `SALES_COACH_PROMPT` AND the full knowledge pack (concatenated chunks for the current brand, capped at 30,000 tokens, refreshed once at session start) in the `system` array, each with `cache_control: { type: "ephemeral" }`. The per-turn user message contains only the rolling transcript + retrieved excerpts (~2k tokens). Log `cache_read_input_tokens` from each response and assert it grows after turn 2.

**Acceptance:** On turn 2 of a session, `cache_read_input_tokens > 20000` in usage logs. p50 TTFT drops by ~40% vs turn 1.

---

## Phase 2 — The three-card UI (~1 day)

Read [UI_SYSTEM.md](./UI_SYSTEM.md) before starting this phase.

### Step 2.1 — Install shadcn + Aceternity + Magic UI + Cult UI

**Prompt:**
> In the renderer (`src/renderer/`), install Tailwind CSS, then `npx shadcn@latest init` with the dark theme defaults. Then install `framer-motion`. Copy these specific components into `src/renderer/components/ui/`:
> - From shadcn: Card, Badge, Button, Tooltip
> - From Aceternity (https://ui.aceternity.com/components): Glare Card, Text Generate Effect, Background Beams, Magnetic Button
> - From Magic UI (https://magicui.design/docs/components): Border Beam, Animated Beam
> - From Cult UI (https://www.cult-ui.com/): Streaming text chat component
>
> Add the `glass-card` utility class to `tailwind.config.ts` using the design tokens from [UI_SYSTEM.md](./UI_SYSTEM.md).

**Acceptance:** Storybook or a /sandbox route renders one of each component cleanly on a dark background.

---

### Step 2.2 — Replace Natively's chat panel with three-card layout

**Prompt:**
> Find the renderer component that displays Natively's chat-style response (probably `src/renderer/components/Overlay.tsx` or similar). Replace it with three cards stacked vertically: `<PrimaryCard>`, `<FactCard>`, `<ObjectionCard>`. Match the spec & exact pixel layout in [UI_SYSTEM.md § The overlay window](./UI_SYSTEM.md). Card backgrounds use the `.glass-card` token. Cards render placeholders when no response is active.

**Acceptance:** Overlay shows three empty card outlines in correct positions. No regressions in existing overlay behavior (shortcuts, hide/show).

---

### Step 2.3 — Stream tokens word-by-word into PrimaryCard

**Prompt:**
> Build `<StreamingText>` per the spec in [UI_SYSTEM.md § Streaming text behavior](./UI_SYSTEM.md). Wire the existing SSE token stream from the backend → split into words → render each via Framer Motion AnimatePresence with the opacity+y+blur in-animation. Show a blinking cursor while `isStreaming=true`. On stream complete, parse the final JSON and populate `<FactCard>` and `<ObjectionCard>` in one frame.

**Acceptance:** Trigger a sample utterance → words appear in PrimaryCard one-by-one within ~1s of speaking; fact & objection appear simultaneously when stream ends.

---

### Step 2.4 — Live badge + controls bar

**Prompt:**
> Above the three cards, add `<LiveBadge>` showing the green pulsing dot, "Live" / prospect name / context. State sources: prospect name from `sessions.prospect_name`, context from a one-line "Tier-2 Indore" sub-label derived from session metadata. Below the cards, add three keyboard hint chips: Pause (Cmd+Shift+P), Pin (Cmd+Shift+I), Note (Cmd+Shift+N). Wire the existing Natively shortcut system to these actions. Pause toggles the badge to amber and stops auto-triggering.

**Acceptance:** All three shortcuts work; badge state matches paused/live correctly.

---

## Phase 3 — Brand multi-tenancy (~half day)

### Step 3.1 — Brand picker launcher

**Prompt:**
> Add a small launcher window (320×400 px) shown before the overlay opens. It lists every brand the user has uploaded documents for, with brand logo + name + last-used timestamp. Selecting a brand: (a) creates a `sessions` row in sqlite, (b) loads that brand's knowledge pack into memory, (c) does one dummy Haiku call to warm the prompt cache, (d) opens the overlay window. Persist last-used brand and pre-select it on launcher open.

**Acceptance:** Launcher → pick brand → overlay opens within 2 seconds with cache warm (verify via logs).

---

### Step 3.2 — Knowledge-pack assembly per brand

**Prompt:**
> Add a function `assembleKnowledgePack(brandId)` that selects all chunks for the brand from sqlite-vec, sorts by `doc_type` priority (termsheet first, brand_voice last), concatenates as labeled markdown sections, hard-caps at 30,000 tokens (tiktoken count). This becomes the second cacheable block in the system prompt. Cache the assembled string in-memory keyed by `(brandId, lastDocUpdateAt)` so repeated session starts within a few minutes skip the assembly.

**Acceptance:** Two consecutive sessions for the same brand assemble the pack only once. Adding a new document invalidates the cache.

---

## Phase 4 — Auto-trigger & session review (~1 day)

### Step 4.1 — Prospect-only turn manager

**Prompt:**
> Natively already has a turn manager that fires on speech_final events. Extend it: only fire when (a) speaker channel = `prospect`, (b) utterance length > 6 words OR contains `?`, (c) 300ms of silence has elapsed. Maintain a rolling 60-second transcript window of both channels (with speaker labels) that gets passed to the LLM on every turn.

**Acceptance:** A test recording with both voices: KISA fires replies only after prospect's complete sentences, never after BDM speech or short "haan/hmm/yeah".

---

### Step 4.2 — Cancel-in-flight on new turn

**Prompt:**
> If a new prospect turn arrives while a previous turn's response is still streaming, abort the in-flight SSE connection on both client and server, clear the cards (with a 200ms fade-out), and start the new turn. Use AbortController on the fetch side and proper Anthropic stream cancellation on the server.

**Acceptance:** Speaking two sentences back-to-back: second response starts streaming within 1s and the first response visibly disappears.

---

### Step 4.3 — Session recording & review screen

**Prompt:**
> On call end (either explicit Stop or 60s of silence), persist the full transcript + every Claude response (with cited chunks) as JSONB into `sessions.transcript`. Add a `Sessions` screen in the launcher window listing past sessions. Clicking one opens a read-only review screen showing the transcript with collapsible "What KISA suggested" rows next to each prospect turn, with chunk citations resolved to clickable source-doc references.

**Acceptance:** End a session, open it from history, see every turn & suggestion. Click a citation → opens the source PDF at the right page.

---

## Phase 5 — Polish & ship (~1 day)

### Step 5.1 — Stealth mode verification

**Prompt:**
> Verify Natively's stealth mode actually hides the KISA overlay during Zoom screen-share. Run a test Zoom call, share the entire screen, have a second device view the call. The overlay should NOT appear in the shared view. If it does, debug Natively's screen-capture filter and fix. Document the result in `SETUP.md`.

**Acceptance:** Verified hidden on Zoom, Google Meet, Teams. Documented.

---

### Step 5.2 — BlackHole / VB-Cable installer flow

**Prompt:**
> On first launch, check whether BlackHole 2ch (mac) or VB-Cable (win) is installed. If not, show a first-run wizard with: (a) a "Download installer" button that opens the official download page in browser, (b) instructions for routing Zoom's speaker output to the virtual cable, (c) a "Test audio capture" button that records 3 seconds and shows the waveform of both channels for confirmation.

**Acceptance:** A fresh-machine test user can get audio capture working in under 5 minutes without external help.

---

### Step 5.3 — Crash reporting & auto-update

**Prompt:**
> Add Sentry to both main and renderer processes (free tier). Add `electron-updater` pointing at GitHub Releases on `jignesh13031998/KISA` and a `pnpm release:mac` / `pnpm release:win` script that builds signed dmg/exe and uploads to a draft release. Document Apple Developer ID and Windows code-signing cert requirements in `RELEASE.md`.

**Acceptance:** A crash in dev surfaces in Sentry. A new release published to GitHub triggers an in-app update prompt within 24h.

---

### Step 5.4 — End-to-end Playwright test

**Prompt:**
> Add one Playwright e2e test that: boots the desktop app in a clean profile, uploads a sample termsheet PDF, starts a session for the test brand, feeds a pre-recorded WAV through a mocked audio path that triggers a turn, asserts the overlay renders all three cards with stream completion within 2 seconds, asserts the cited chunk ID matches a known section of the test termsheet. Run in CI on PRs.

**Acceptance:** Test passes locally and in CI.

---

## How to use this guide with terminal Claude

1. Open the cloned KISA repo in terminal Claude.
2. Paste **only one step's prompt at a time** — never batch.
3. After Claude finishes, run the **Acceptance** check yourself before moving on.
4. If a step fails, reply with the exact error — don't accept "should work".
5. Commit after every passing step (`feat: phase 1.3 intent classifier`).
6. At the end of each phase, rebase against `upstream/main` to absorb Natively security fixes.

If you skip Phase 5 entirely, you still have a working internal-use tool by end of Phase 4. Phase 5 is only required for external distribution.
