# KISA

**A real-time AI co-pilot for franchise pitching.**

KISA overlays your live Zoom calls, listens to the conversation, and streams Claude-generated, document-grounded responses onto your screen in under a second — so you read, speak, and close, never type.

Inspired by Parateek.ai, purpose-built for Business Development Managers pitching franchise opportunities to prospective investors.

---

## How it works

1. Captures your mic + Zoom's system audio via a virtual audio driver
2. Streams both channels to Deepgram (cloud) or Whisper-large-v3-turbo (local) for real-time transcription with speaker diarization
3. On every prospect-turn-end, retrieves the most relevant excerpts from your uploaded Termsheet, General Conditions, FAQs, Unit Economics
4. Asks Claude Haiku 4.5 (with prompt-cached knowledge base) for a grounded, three-card response
5. Streams tokens onto a transparent always-on-top overlay built with Glassmorphism 2.0

End-to-end latency target: **< 1.2 seconds** from prospect's last word to first token on your screen.

---

## Build strategy

KISA is a **fork-first** project. Instead of building from scratch, we fork [Natively](https://github.com/evinjohnn/natively-cluely-ai-assistant) (AGPL-3.0) — a mature open-source meeting copilot that already provides 80% of the infrastructure we need — and add the franchise-sales-specific layer on top.

This saves ~4 weeks of engineering and ~70% of token spend during development.

---

## Documentation

Read in this order:

1. **[STACK.md](./docs/STACK.md)** — verified tech stack, what we reuse vs build, license analysis
2. **[ARCHITECTURE.md](./docs/ARCHITECTURE.md)** — system design, latency budget, data flow, cost model
3. **[UI_SYSTEM.md](./docs/UI_SYSTEM.md)** — Glassmorphism 2.0 design system, three-card overlay spec, component library
4. **[BUILD_GUIDE.md](./docs/BUILD_GUIDE.md)** — step-by-step fork & customize playbook for Claude Code

---

## Status

Planning complete. Stack verified. MVP build target: **5 working days, 1 engineer.**

## License

The KISA delta will be released under the same AGPL-3.0 license as Natively. For closed-source commercial deployment, a commercial license from Natively's maintainers is required.
