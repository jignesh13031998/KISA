# KISA — Step-by-Step Build Guide

A copy-paste-ready playbook for implementing KISA with Claude Code. Each step is a self-contained prompt with a clear acceptance test. Run them in order, verify each before moving on.

---

## Phase 0 — Bootstrap (~30 min)

### Step 0.1 — Monorepo skeleton

**Prompt to terminal Claude:**
> Initialize a pnpm monorepo at the current directory with three workspaces: `apps/desktop` (Electron + React + Vite + TypeScript), `apps/server` (Node + Fastify + TypeScript + tsx), and `packages/shared` (TypeScript types only). Add a root `.gitignore`, `README.md` with one-line description "BDM AI Co-Pilot for franchise pitching", and a root `package.json` with `dev:desktop` and `dev:server` scripts. Do not add any business logic yet.

**Acceptance:** `pnpm i` works, `pnpm dev:desktop` opens an empty Electron window, `pnpm dev:server` boots Fastify on `:8787` returning `{ok:true}` at `/health`.

---

### Step 0.2 — Secrets & config

**Prompt:**
> Create `.env.example` at the repo root with these keys (no real values): `DEEPGRAM_API_KEY`, `ANTHROPIC_API_KEY`, `VOYAGE_API_KEY`, `SUPABASE_URL`, `SUPABASE_SERVICE_KEY`, `SUPABASE_ANON_KEY`. In `apps/server`, add a `src/config.ts` that loads env via `zod` and crashes early if anything is missing. Wire `dotenv` from the repo root.

**Acceptance:** Server crashes cleanly with a readable error if any env var is missing.

---

### Step 0.3 — Supabase project + schema

**Prompt:**
> Add a `supabase/migrations/0001_init.sql` file with these tables: `brands(id, name, owner_user_id, created_at)`, `documents(id, brand_id, doc_type enum['termsheet','general_conditions','faq','unit_economics','pitch_deck','brand_voice'], filename, storage_path, created_at)`, `chunks(id, document_id, brand_id, doc_type, page, section, text, embedding vector(512), created_at)` with `pgvector` extension enabled and an HNSW index on `chunks.embedding`. Also `sessions(id, brand_id, user_id, started_at, ended_at, transcript jsonb)`. Add a brief `supabase/README.md` with the two CLI commands to apply the migration locally.

**Acceptance:** `supabase db reset` runs the migration cleanly; `\d chunks` shows the vector column and HNSW index.

---

## Phase 1 — Listen (~1 day)

### Step 1.1 — Audio device picker

**Prompt:**
> In `apps/desktop`, add a settings screen that lists all input audio devices via `navigator.mediaDevices.enumerateDevices()` and lets the user pick TWO devices: "My mic" and "Zoom output (virtual cable)". Persist selections to `electron-store`. Add a markdown `apps/desktop/SETUP.md` with one paragraph each on installing **BlackHole 2ch (macOS)** and **VB-Audio Cable (Windows)** and routing Zoom's speaker to it.

**Acceptance:** App remembers chosen devices across restarts; SETUP.md is correct and concise.

---

### Step 1.2 — Dual-channel PCM capture

**Prompt:**
> In `apps/desktop`, capture both selected devices as `MediaStream`s, downsample to 16kHz mono PCM 16-bit using an `AudioWorklet`, and emit two parallel streams labeled `"bdm"` and `"prospect"`. Show a live VU meter for each in the dev window. No network calls yet.

**Acceptance:** Both VU meters move when you talk into mic / play sound through Zoom.

---

### Step 1.3 — Deepgram streaming

**Prompt:**
> Open one Deepgram Nova-3 WebSocket per channel (`?model=nova-3&encoding=linear16&sample_rate=16000&interim_results=true&endpointing=400&vad_events=true`). Pipe PCM frames in. Render interim + final transcripts in a simple two-column live view (left = BDM, right = Prospect). Reconnect with exponential backoff on drop. Keep code in `apps/desktop/src/audio/deepgram.ts`.

**Acceptance:** Live captions appear in <500ms with the correct speaker column.

---

## Phase 2 — Ingest knowledge (~1 day)

### Step 2.1 — Server: doc upload

**Prompt:**
> In `apps/server`, add `POST /brands/:brandId/documents` that accepts a multipart PDF/MD/XLSX, uploads the raw file to Supabase Storage under `brand/{brandId}/{uuid}.{ext}`, and inserts a `documents` row. Use `@fastify/multipart`. No chunking yet. Return `{documentId}`.

**Acceptance:** `curl` upload returns a documentId; file visible in Supabase Storage.

---

### Step 2.2 — Parse + chunk

**Prompt:**
> Add a worker function `ingest(documentId)` that downloads the file from Storage, extracts text (use `pdf-parse` for PDF, plain read for MD, `xlsx` for spreadsheets), splits into ~800-token chunks with 100-token overlap (use `tiktoken` for token counting), and inserts rows into `chunks` with `page` and `section` metadata when available. Trigger it inline at the end of the upload endpoint for now.

**Acceptance:** After uploading a sample termsheet PDF, `select count(*) from chunks` returns >0 with non-empty text.

---

### Step 2.3 — Embed with Voyage

**Prompt:**
> Extend `ingest()` to call Voyage `voyage-3-lite` (input_type="document", batch of 64) to generate 512-dim embeddings and update each chunk's `embedding` column. Add a small `embed.ts` module wrapping the Voyage HTTP API with retries on 429/5xx.

**Acceptance:** All chunks have non-null `embedding`; a sanity SQL `SELECT id FROM chunks ORDER BY embedding <=> (SELECT embedding FROM chunks LIMIT 1) LIMIT 5` returns ranked results.

---

### Step 2.4 — Retrieval endpoint

**Prompt:**
> Add `POST /brands/:brandId/retrieve` taking `{query: string, docTypes?: string[], k?: number}`. Embed the query with Voyage (input_type="query"), run pgvector cosine search filtered by `brand_id` and optional `doc_types`, return top-k chunks with text + metadata. Default k=4.

**Acceptance:** Hitting it with "what is the royalty fee" returns chunks from termsheet/FAQ.

---

## Phase 3 — Reason (~1 day)

### Step 3.1 — Claude Haiku, no streaming yet

**Prompt:**
> Add `POST /sessions/:sessionId/respond` that takes `{prospectUtterance, transcriptWindow}`. Inside: classify intent (cheap Haiku one-liner returning one of `commercials|legal|objection|roi|story|general`), call `/retrieve` with that doc filter, then call Claude `claude-haiku-4-5-20251001` with a strict JSON schema returning `{reply, key_fact, objection_handler}`. `reply` <= 35 words. Return the JSON.

**Acceptance:** Curl with a sample utterance returns a coherent JSON in <1.5s.

---

### Step 3.2 — Prompt caching

**Prompt:**
> Refactor the Claude call to use the Anthropic SDK's prompt caching: place the static `SALES_COACH_PROMPT` and the **full brand knowledge pack** (concatenated chunks for that brand, capped at 30k tokens, refreshed at session start) in the `system` array with `cache_control: { type: "ephemeral" }`. Per-turn user message contains only the rolling transcript + retrieved excerpts. Verify cache_read_input_tokens > 0 in response usage and log it.

**Acceptance:** On second call within 5 min, response usage shows `cache_read_input_tokens` ~ knowledge-pack size; latency drops noticeably.

---

### Step 3.3 — SSE streaming to client

**Prompt:**
> Convert `/respond` to an SSE endpoint that streams Claude tokens. Use `messages.stream()` from the Anthropic SDK and forward `text_delta` events as SSE `data:` frames. Keep the JSON schema by streaming each field's text as it generates (use Anthropic's structured streaming or stream raw + parse on client).

**Acceptance:** `curl -N` shows tokens arriving progressively, first token in <500ms after the cache is warm.

---

## Phase 4 — Overlay UI (~1 day)

### Step 4.1 — Transparent always-on-top window

**Prompt:**
> In `apps/desktop`, add a second BrowserWindow `overlay` with options `{ transparent: true, frame: false, alwaysOnTop: true, hasShadow: false, resizable: false, width: 380, height: 520 }`. Position top-right of primary display. Set `setIgnoreMouseEvents(true, { forward: true })` by default and toggle to false when hovering the cards (use CSS `pointer-events`). Set always-on-top level to `screen-saver` so it stays above Zoom.

**Acceptance:** Overlay floats above Zoom, mouse passes through empty space, clicks land on cards.

---

### Step 4.2 — Three-card layout

**Prompt:**
> Build the overlay React UI with three cards as specified: (1) "SAY THIS" (large, primary), (2) "KEY FACT" (compact with source ref), (3) "IF THEY PUSH BACK". Use Tailwind + a dark glassmorphism style (bg `rgba(15,15,20,0.85)`, backdrop-blur, white text). Show a subtle "● Live" pill at the top with the prospect's name from session.

**Acceptance:** Static mock renders cleanly, readable over any Zoom background.

---

### Step 4.3 — Wire SSE → cards

**Prompt:**
> Connect the overlay to `/sessions/:id/respond` SSE. Stream `reply` field token-by-token into card (1). Render `key_fact` and `objection_handler` once their fields finish. Add a typing-cursor animation while streaming. Cancel any in-flight SSE if a new turn arrives.

**Acceptance:** Tokens appear word-by-word in <1s of triggering; new requests cleanly cancel old ones.

---

## Phase 5 — Auto-trigger (~1 day)

### Step 5.1 — Turn manager

**Prompt:**
> Add a `TurnManager` class in the desktop app that consumes Deepgram events. Trigger `/respond` only when: (a) the speaker is `"prospect"`, (b) Deepgram emits `speech_final=true`, (c) utterance length > 6 words OR contains a `?`. Debounce 300ms to allow the prospect to continue. Maintain a rolling 60s transcript window passed to the server.

**Acceptance:** Reply only fires for prospect's complete sentences, never for your own voice or short "hmm/yeah".

---

### Step 5.2 — Manual override controls

**Prompt:**
> Add three keyboard shortcuts: `Cmd+Shift+P` pause auto-mode, `Cmd+Shift+R` re-run on last utterance, `Cmd+Shift+H` hide/show overlay. Show pause state in the "● Live" pill (turns amber when paused).

**Acceptance:** All three shortcuts work with overlay focused or unfocused.

---

## Phase 6 — Multi-tenancy & polish (~1 day)

### Step 6.1 — Brand picker + session start

**Prompt:**
> Before a call, show a small launcher window listing all brands the user owns. Selecting one creates a `sessions` row, fetches & caches the brand's knowledge pack on the server (warming the prompt cache with one dummy Haiku call), and opens the overlay. Persist last-used brand.

**Acceptance:** Choosing a brand shows the overlay within 2s with the prompt cache pre-warmed.

---

### Step 6.2 — Session recording & review

**Prompt:**
> On call end, persist the full transcript and every Claude response to `sessions.transcript` as JSONB. Add `apps/desktop` review screen `/sessions/:id` showing transcript with collapsible "what Claude suggested" rows next to each prospect turn. No edit, just read-only review.

**Acceptance:** After ending a session, you can replay it and see your AI suggestions inline.

---

## Phase 7 — Ship checklist (~half day)

**Prompt:**
> Add: (1) crash-reporter via Sentry in both apps, (2) `pnpm package:mac` and `pnpm package:win` scripts using `electron-builder` producing signed dmg/exe, (3) auto-update via `electron-updater` pointing to a GitHub Releases bucket, (4) one Playwright e2e test that boots the desktop app, mocks Deepgram + Anthropic, and asserts the overlay renders a streamed reply.

**Acceptance:** Signed installer runs on a clean machine; e2e test green in CI.

---

## How to use this with terminal Claude

1. Open your repo in terminal Claude.
2. Paste **only one step's prompt** at a time — never batch.
3. After Claude finishes, run the **Acceptance** check yourself before moving on.
4. If a step fails, reply with the exact error — don't accept "should work".
5. Commit after every passing step (e.g. `feat: phase 1.3 deepgram streaming`).

**Total time, single engineer:** ~6–7 working days to shippable v1.
