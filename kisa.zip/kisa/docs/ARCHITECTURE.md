# KISA — Architecture

A minimal, latency-first architecture for a real-time BDM AI co-pilot that helps Business Development Managers pitch franchise opportunities to prospective investors over Zoom.

---

## 1. Product in one sentence

A transparent always-on-top overlay that listens to your live Zoom call, understands what the prospective franchisee just said, and streams Claude-generated, document-grounded responses onto your screen within ~1 second — so you read & speak, never type.

---

## 2. The Latency Budget (the only number that matters)

End-to-end target: **< 1,200 ms** from prospect's last word → first token on your screen.

| Stage | Budget | Tech |
|---|---|---|
| Audio capture → STT first partial | 250 ms | Deepgram Nova-3 streaming (WSS) |
| End-of-utterance detection (VAD) | 400 ms | Deepgram `endpointing=400` |
| Retrieval (top-k from KB) | 80 ms | pgvector (HNSW) or Pinecone serverless |
| Claude TTFT (Time-To-First-Token) | 350 ms | Claude **Haiku 4.5** + **prompt caching** on KB |
| UI render | 20 ms | React + IPC stream |
| **Total to first token** | **~1.1 s** | |

> Prompt caching cuts ~70% of input cost & latency because Termsheet + GC + FAQs are **identical every turn**.

---

## 3. End-to-End Flow

```
┌────────────────────────────────────────────────────────────────────┐
│  Zoom Call (Mac/Win desktop)                                       │
│   ├─ Mic (You / BDM)                                               │
│   └─ System Audio (Prospect)  ── via virtual audio driver          │
└──────────────────────────┬─────────────────────────────────────────┘
                           │  16-bit PCM, 16kHz, dual-channel
                           ▼
┌────────────────────────────────────────────────────────────────────┐
│  Electron Desktop App  (transparent, always-on-top, click-through) │
│                                                                    │
│  ┌──────────────┐   ┌─────────────────┐   ┌────────────────────┐   │
│  │ Audio Mixer  │──▶│ Deepgram WSS    │──▶│ Turn Manager       │   │
│  │ (2 channels) │   │ diarized + VAD  │   │ (debounce 400ms)   │   │
│  └──────────────┘   └─────────────────┘   └─────────┬──────────┘   │
│                                                     │              │
│                                                     ▼              │
│                                          ┌───────────────────────┐ │
│                                          │ Co-Pilot Backend (WS) │ │
│                                          └───────────────────────┘ │
│                                                                    │
│  ┌──────────────────────────────────────────────────────────────┐  │
│  │  OVERLAY UI  ──  3 cards, streamed:                          │  │
│  │  (1) Suggested Reply  (2) Key Fact  (3) Objection Brief      │  │
│  └──────────────────────────────────────────────────────────────┘  │
└──────────────────────────┬─────────────────────────────────────────┘
                           │  WebSocket (transcript chunks)
                           ▼
┌────────────────────────────────────────────────────────────────────┐
│  Backend  (Node/Fastify on Fly.io, single region near user)        │
│                                                                    │
│  ┌──────────────┐   ┌──────────────┐   ┌────────────────────────┐  │
│  │ Conversation │──▶│ Retriever    │──▶│ Claude Haiku 4.5       │  │
│  │ State (Redis)│   │ pgvector HNSW│   │ streaming + cached KB  │  │
│  └──────────────┘   └──────────────┘   └───────────┬────────────┘  │
│                                                    │ SSE tokens    │
└────────────────────────────────────────────────────┼───────────────┘
                                                    ▼
                                          back to Overlay UI
```

---

## 4. The Minimal Stack (one choice per layer)

| Layer | Choice | Why this and not the alternative |
|---|---|---|
| **Desktop shell** | **Electron** (Win + Mac) | Only way to get system audio + true overlay. Zoom Apps SDK is sandboxed; Chrome extension can't capture native Zoom. |
| **Audio routing** | **BlackHole (mac)** / **VB-Cable (win)**, auto-installed | Captures Zoom output without Zoom integration. Zero cooperation from Zoom needed. |
| **STT** | **Deepgram Nova-3 streaming** with `diarize=true`, `endpointing=400`, `interim_results=true` | Lowest TTFT in market (~250ms), built-in speaker turns, $0.0043/min. |
| **Vector DB** | **Postgres + pgvector (HNSW)** on Supabase | One DB for docs, sessions, embeddings. No second service. Sub-100ms p99 for <1M chunks. |
| **Embeddings** | **Voyage-3-lite** (512-dim) | Cheapest high-quality, runs once at upload. |
| **LLM** | **Claude Haiku 4.5** (`claude-haiku-4-5-20251001`) with **prompt caching** | Haiku TTFT ~350ms, smart enough for grounded sales replies. Sonnet 4.6 as fallback for "deep objection" mode. |
| **Backend** | **Node + Fastify**, single edge region (Mumbai) | One language across desktop & server. Fly.io Mumbai keeps RTT <30ms for Indian users. |
| **State** | **Redis (Upstash)** for rolling transcript, **Postgres** for everything else | |
| **Doc ingest** | `unstructured.io` or `pdf-parse` → chunk 800 tokens, 100 overlap | Standard. Run once per upload. |
| **Auth + storage** | **Supabase (Auth + S3-compatible Storage)** | Single vendor for auth, DB, vector, files. |

---

## 5. The Knowledge Pack (per franchise brand)

Uploaded once by admin, versioned:

```
/brand/{brand_id}/
  ├── termsheet.pdf          → chunked, embedded, tagged "commercials"
  ├── general_conditions.pdf → tagged "legal"
  ├── faqs.md                → tagged "objection"
  ├── unit_economics.xlsx    → tagged "roi"
  ├── pitch_deck.pdf         → tagged "story"
  └── brand_voice.md         → injected as system prompt (tone)
```

Each chunk carries metadata `{brand_id, doc_type, page, section}` so retrieval can **filter by intent** (e.g., investor asks about money → only `commercials` + `roi`).

---

## 6. The Reasoning Loop (the heart)

On every detected **prospect-turn-end**:

```python
# Pseudocode — one round-trip
turn = transcript.last_prospect_utterance()
intent = classify(turn)            # cheap: regex + Haiku one-liner
chunks = pgvector.search(
    query=turn,
    filter={"brand_id": session.brand, "doc_type": intent.docs},
    k=4
)

claude.messages.stream(
    model="claude-haiku-4-5-20251001",
    system=[
        {"type": "text", "text": SALES_COACH_PROMPT, "cache_control": {"type": "ephemeral"}},
        {"type": "text", "text": KNOWLEDGE_PACK,    "cache_control": {"type": "ephemeral"}},
    ],
    messages=[
        {"role": "user", "content": f"""
        ROLLING TRANSCRIPT (last 60s):
        {transcript.window(60)}

        PROSPECT JUST SAID: "{turn}"

        RELEVANT EXCERPTS:
        {format(chunks)}

        Respond in the JSON schema: {reply, key_fact, objection_handler}
        Keep `reply` under 35 words, conversational, first-person.
        """}
    ],
    max_tokens=300,
)
```

**Three things this prompt does:**
1. **Caches** the 20–40k token knowledge pack — paid once per 5 min, then ~10x cheaper & faster.
2. **Constrains** output to 3 short cards — no walls of text on overlay.
3. **Grounds** on excerpts with page refs — every claim is auditable.

---

## 7. The Overlay UI (what the BDM actually sees)

Transparent 380×520 px window, top-right of screen, click-through except on cards.

```
┌─────────────────────────────────────────┐
│  ● Live  ·  Investor: Rajesh M.         │
├─────────────────────────────────────────┤
│  SAY THIS                               │
│  "Our Tier-2 outlets break even in      │
│   14 months on average — I can show     │
│   you the Indore P&L right now."        │
├─────────────────────────────────────────┤
│  KEY FACT                               │
│  Avg payback: 14 mo  ·  ROI: 38% Y2     │
│  Termsheet §4.2                         │
├─────────────────────────────────────────┤
│  IF THEY PUSH BACK                      │
│  On royalty (8%): justify with brand    │
│  marketing spend ₹12 Cr/yr — FAQ #11    │
└─────────────────────────────────────────┘
   [Pause]  [Pin]  [Note]
```

Streamed tokens appear word-by-word in card (1) so you can start reading before generation finishes.

---

## 8. The Minimal MVP — what to build first

**Week 1 — Listening proof:**
Electron + BlackHole + Deepgram → live transcript window. Nothing else.

**Week 2 — Grounded reply:**
Upload one termsheet → pgvector → Claude Haiku → render reply card. Manual trigger button.

**Week 3 — Auto-trigger:**
VAD-based turn detection + diarization filter (only react when *prospect* talks, never to your own voice).

**Week 4 — Polish:**
Always-on-top overlay, prompt caching, brand multi-tenancy, session recording for review.

That's a 4-week, 1-engineer MVP.

---

## 9. What to deliberately leave out (for now)

- No fine-tuning. Prompt caching + RAG is enough.
- No Zoom App / Zoom SDK integration. Virtual audio is faster to ship and Zoom-version-proof.
- No on-device LLM. Haiku via API is faster than any 8B local model on a MacBook.
- No agentic tool-use. One LLM call per turn. Predictable latency > clever orchestration.
- No CRM write-back in v1. Add Salesforce/HubSpot push in v2 from session transcripts.

---

## 10. Cost (per 60-min call)

| Item | Cost |
|---|---|
| Deepgram STT | ₹22 |
| Claude Haiku (cached KB, ~40 turns) | ₹18 |
| pgvector queries | ~₹0 |
| Infra amortized | ₹2 |
| **Per call** | **~₹42** |

At 500 calls/month/BDM, that's **₹21k/mo gross cost** — easily a ₹2k/BDM/mo SaaS price.
