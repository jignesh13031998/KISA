# KISA

**A real-time AI co-pilot for franchise pitching.**

KISA overlays your live Zoom calls, listens to the conversation, and streams Claude-generated, document-grounded responses onto your screen in under a second — so you read, speak, and close, never type.

Inspired by Parateek.ai, purpose-built for Business Development Managers pitching franchise opportunities to prospective investors.

---

## How it works

1. Captures your mic + Zoom's system audio via a virtual audio driver
2. Streams both channels to Deepgram for real-time transcription with speaker diarization
3. On every prospect-turn-end, retrieves the most relevant excerpts from your uploaded Termsheet, General Conditions, FAQs, Unit Economics
4. Asks Claude Haiku 4.5 (with prompt-cached knowledge base) for a grounded, three-card response
5. Streams tokens onto a transparent always-on-top overlay

End-to-end latency target: **< 1.2 seconds** from prospect's last word to first token on your screen.

---

## Documentation

- **[Architecture](./docs/ARCHITECTURE.md)** — system design, tech stack rationale, latency budget, cost model
- **[Build Guide](./docs/BUILD_GUIDE.md)** — step-by-step implementation playbook to feed into Claude Code

---

## Status

Planning complete. MVP build target: **4–7 working days, 1 engineer.**

## License

Proprietary — internal use only.
